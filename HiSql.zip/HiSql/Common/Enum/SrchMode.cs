﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HiSql
{
    public enum SrchMode
    {
        Single=10,//单值查询
        Range=20,//范围查询
        Multi=30,//多值查询
    }
}
