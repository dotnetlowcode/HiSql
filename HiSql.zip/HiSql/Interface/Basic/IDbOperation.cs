﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HiSql
{
    /// <summary>
    /// 数据库操作运维接口
    /// </summary>
    public interface IDbOperation
    {
    }
}
